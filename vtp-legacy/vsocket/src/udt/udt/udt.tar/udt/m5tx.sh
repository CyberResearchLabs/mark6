#!/bin/bash

cat input.dat | nc -vv 127.0.0.1 2630
