#!/bin/bash

# ./vrtp -s -i 127.0.0.1 -p 49000 -F input.dat -D 2 -n 8 -r 0
# ./vrtp -s -i 0.0.0.0 -p 1025 -I 127.0.0.1 -P 49000 -F input.dat -D 3 -n 8 -r 1

./appserver  &
# sleep 2
# cat input.dat | nc -vv 127.0.0.1 2630
