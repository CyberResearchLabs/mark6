#include <iostream>
#include <udt.h>
#include <tcpsocket.h>
#include <unistd.h>



int main()
{
        CUDT* server = new CUDT;
	bool boolval=false;
	server->setOpt(UDT_SNDSYN, &boolval, sizeof(bool));
   TCPSocket in_sock;
   string local_ip("0.0.0.0");
   int local_port(2630);
   in_sock.bind(local_ip, local_port);

	try
	{
		//bind to any free port number
		int serverport = server->open(7000);
		cout << "server is read at port: " << serverport << endl;
		//waiting for a client
		server->listen();
		cerr << "server received incoming cnonection from client\n";

   		in_sock.listen();
   		in_sock.accept();
   		cerr << "Server received connection from incoming Mark5\n";
	}
	catch(CUDTException e)
	{
		cout << "error msg: " << e.getErrorMessage();
		return 0;
	}

   	char data[1400];
   	int bytes_rcvd=0;
   	while ((bytes_rcvd=in_sock.recv(data, 1400))>0) {
		server->send(data, bytes_rcvd);
		cerr << "sent a packet\n";
	while (server->getCurrSndBufSize() > 1400)
		usleep(10);
	}
	server->close();
	in_sock.shutdown(SHUT_RDWR);
	in_sock.close();

	return 1;
}
