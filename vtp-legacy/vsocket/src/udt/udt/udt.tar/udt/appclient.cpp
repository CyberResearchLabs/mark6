#include <iostream>
#include <udt.h>
#include <tcpsocket.h>
#include <string>
#include <iostream>

int main(int argc, char** argv)
{
	CUDT* client = new CUDT;
	TCPSocket out_sock;
	string local_ip("127.0.0.1");
	int local_port(2631);
	out_sock.connect(local_ip, local_port);
	cerr << "Connected to rx m5\n";

	try  {
		client->open();
		client->connect(local_ip.c_str(), 7000);
		cerr << "Connected to incoming stream\n";
		char data[1400];
		int bytes_wrtn=0;
		while (1) {
				client->recv(data, 2400);
				cerr << "Received a packet\n";
				out_sock.send(data, 1400);
		}
	} catch (CUDTException e) {
		cerr << " some problem: " << e.getErrorMessage() << "\n";
	}
	client->close();
	out_sock.shutdown(SHUT_RDWR);
	out_sock.close();
return 1;
}
